// import { Page } from "@shopify/polaris";
// import ScheduleConfig from "../components/scheduleconfig";

// export default function ScheduleModal() {
//   return (
//     <Page>
//       <ScheduleConfig />
//     </Page>
//   );
// }
